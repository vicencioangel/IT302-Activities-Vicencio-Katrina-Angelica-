<?php

$x = "anton";
$q = 1;
$w = 1.5;
$e = true;
$t = [];
$y = null;
var_dump($x);
var_dump($q);
var_dump($w);
var_dump($e);
var_dump($t);
class car{
	
}
var_dump($y);
?>