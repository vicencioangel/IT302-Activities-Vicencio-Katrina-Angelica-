<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php
$x='antonio c. quiawan';
$y='BsInfo3A';

echo "Name: $x</br>";
echo "Course: $y";
?>
</body>
</html>
